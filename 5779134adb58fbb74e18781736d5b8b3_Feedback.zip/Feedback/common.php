<?php
$login="";
$registration;
$userlist="";
$professorlist ="";
$studentlist ="";
$feedbacklist ="";
$subjectlist = "";
$title = "Home";
$show = "";
